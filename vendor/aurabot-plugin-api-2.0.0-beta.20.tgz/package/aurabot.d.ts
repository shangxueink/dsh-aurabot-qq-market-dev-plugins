// Aurabot 插件类型（v2）。插件每次启动会把这份文件同步到 modules/ 下，别改它。
//
// 写法只有一种：
//   export const name = '…'; export function apply(ctx, config) { … }
//
// VS Code 里把入口写成 .ts，或在 .mjs 顶上写
//   /** @type {import('./aurabot').AurabotModule} */
// 就能拿到 ctx / session / h 的完整补全。

export interface Element {
  type: string
  attrs: Record<string, any>
  children?: Element[]
}

export type ElementSource = string | Element | Element[] | null | undefined
export type Selector = string | ((element: Element) => boolean)

/** 全局 `h`（宿主注入，不用 import）。 */
export interface ElementFactory {
  (type: string, attrs?: Record<string, any>, children?: Element[]): Element
  text(content: string): Element
  at(id: string | number, name?: string): Element
  image(url: string, extra?: Record<string, any>): Element
  voice(url: string, extra?: Record<string, any>): Element
  video(url: string, extra?: Record<string, any>): Element
  file(url: string, name?: string): Element
  face(id: string | number): Element
  poke(id?: string | number): Element
  quote(id: string | number): Element
  forward(idOrChildren: string | number | Element[]): Element
  parse(source: string): Element[]
  stringify(source: ElementSource): string
  select(source: ElementSource, selector: Selector): Element[]
  normalize(source: ElementSource): Element[]
  degrade(source: ElementSource, supports: (capability: Capability) => boolean): Element[]
  isElement(value: unknown): value is Element
}

export type Capability =
  | 'text' | 'at' | 'face' | 'image' | 'voice' | 'video' | 'file'
  | 'forward' | 'markdown' | 'html' | 'satori' | 'quote' | 'reaction' | 'poke'

export type BotStatus = 'registered' | 'connecting' | 'online' | 'offline' | 'error'

export interface SendOptions {
  replyTo?: string
  timeoutMs?: number
}

export interface ModuleSendOptions extends SendOptions {
  proactive?: boolean
  proactiveCause?: string
}

export interface User {
  id: string
  name?: string
  nick?: string
  avatar?: string
  isBot?: boolean
  raw?: unknown
}

export interface Guild {
  id: string
  name?: string
  avatar?: string
  raw?: unknown
}

export type ChannelType = 'text' | 'voice' | 'category' | 'direct'

export interface Channel {
  id: string
  type: ChannelType
  name?: string
  guildId?: string
  parentId?: string
  raw?: unknown
}

export interface GuildMember {
  user: User
  nick?: string
  roles?: string[]
  joinedAt?: number
  raw?: unknown
}

export interface Message {
  userName?: string
  channelType?: 'private' | 'group' | 'channel'
  id: string
  channelId: string
  userId: string
  content: string
  elements?: Element[]
  createdAt?: number
  raw?: unknown
}

/** 一个已上线的机器人。资源方法对齐 Satori；平台不支持的会抛 UnsupportedApiError。 */
export declare abstract class Bot {
  abstract readonly id: string
  abstract readonly platform: string
  abstract readonly selfId: string
  abstract readonly status: BotStatus
  abstract supports(capability: Capability): boolean

  abstract sendMessage(channelId: string, content: unknown, options?: SendOptions): Promise<unknown>
  abstract sendPrivateMessage(userId: string, content: unknown, options?: SendOptions): Promise<unknown>

  getSelfId(): string
  getSelf(): Promise<User>
  getUser(userId: string): Promise<User>
  getFriendList(): Promise<User[]>
  getGuild(guildId: string): Promise<Guild>
  getGuildList(): Promise<Guild[]>
  getUserList(guildId: string): Promise<GuildMember[]>
  getChannel(channelId: string, type?: Message['channelType']): Promise<Channel>
  getChannelList(guildId: string): Promise<Channel[]>
  getMessage(channelId: string, messageId: string): Promise<Message>
  getMessageList(id: string, query?: { address?: 'channel' | 'user'; channelType?: Message['channelType']; limit?: number; next?: string; order?: 'asc' | 'desc' }): Promise<Message[]>
  deleteMessage(channelId: string, messageId: string): Promise<void>
  updateMessage(channelId: string, messageId: string, content: unknown): Promise<Message>
  /** 平台原生调用：QQ 是 OneBot action，Telegram 是 Bot API 方法名。不支持的平台抛错。 */
  internal<T = any>(action: string, params?: Record<string, unknown>, options?: { timeoutMs?: number }): Promise<T>
  createReaction(channelId: string, messageId: string, emoji: string): Promise<void>
  deleteReaction(channelId: string, messageId: string, emoji: string): Promise<void>
  /** 显示「正在输入」；平台不支持时什么也不做。 */
  sendTyping(channelId: string, type?: Message['channelType']): Promise<void>
  /** 把聊天文件换成可下载地址；拿不到返回空串。 */
  getFileUrl(channelId: string, file: FileRef, type?: Message['channelType']): Promise<string>
}

/** 聊天里收到的文件。id/extra 是平台取件凭据，原样交给 getFileUrl。 */
export interface FileRef {
  name: string
  id?: string
  url?: string
  extra?: Record<string, unknown>
}

/** 三种取法：ctx.bots[0] / ctx.bots('号') / ctx.bots.list()。 */
export type BotsAccessor = Bot[] & {
  (id: string, platform?: string): Bot | undefined
  get(id: string, platform?: string): Bot | undefined
  list(): Bot[]
}

export interface Target {
  platform: string
  botId: string
  type: 'private' | 'group' | 'channel'
  id: string
}

/** 一条入站消息。所有发送方法都是异步的，调用方一律 await。 */
export interface MessageQuote {
  id: string
  channelId: string
  userId?: string
  content?: string
  createdAt?: number
  deletedAt?: number
}

export interface Session {
  readonly authority: number
  authorize(userId: string, level: number): Promise<void>
  readonly quote?: MessageQuote
  readonly bot: Bot
  readonly type: Target['type']
  readonly channelId: string
  readonly userId: string
  readonly userName: string
  readonly content: string
  readonly messageId?: string
  readonly sn?: number
  readonly id?: string
  readonly guildId?: string
  readonly elements: Element[]
  readonly timestamp: number
  readonly target: Target
  readonly platform: string
  readonly isPrivate: boolean
  /** 发回当前会话；可以多次调用，每次一条独立消息。 */
  send(content: unknown, options?: SendOptions): Promise<unknown>
  sendPrivateMessage(userId: string, content: unknown, options?: SendOptions): Promise<unknown>
  sendMessage(channelId: string, content: unknown, options?: SendOptions): Promise<unknown>
  /**
   * 以当前会话身份再发一遍：过指令 / 中间件 / 模型三段，该发出去的真发。
   * 等价于「用户又发了这句话」，不是本地空跑。递归深度限 1。
   */
  execute(text: string): Promise<PipelineResult>
}

export interface MessageDraft {
  readonly messageId?: string
  readonly platform: string
  readonly botId: string
  readonly type: Target['type']
  readonly userId: string
  readonly channelId: string
  readonly guildId?: string
  elements: Element[]
}

export interface SendEvent {
  readonly bot: Bot
  readonly platform: string
  readonly botId: string
  readonly type: Target['type']
  readonly target: Target
  readonly elements: Element[]
  readonly channelId?: string
  readonly userId?: string
  readonly messageId?: string
}

export type NoticeName = 'guild-added' | 'guild-updated' | 'guild-removed' | 'guild-request' | 'friend-request'
  | 'guild-member-added' | 'guild-member-updated' | 'guild-member-removed' | 'guild-member-request'
  | 'guild-role-created' | 'guild-role-updated' | 'guild-role-deleted'
  | 'message-deleted' | 'message-updated' | 'reaction-added' | 'reaction-removed'

export interface PlatformNotice {
  readonly bot: Bot
  readonly platform: string
  readonly botId: string
  readonly selfId: string
  readonly event: NoticeName
  readonly data: Record<string, unknown>
  readonly type: 'group' | 'private'
  readonly userId?: string
  readonly channelId?: string
  readonly guildId?: string
  readonly messageId?: string
  readonly timestamp: number
  readonly sn?: number
}

export interface PipelineResult {
  handled: boolean
  by: 'command' | 'middleware' | 'llm' | null
  value?: unknown
  error?: string
}

export type Next = () => Promise<PipelineResult>

export type Middleware = (session: Session, next: Next) => unknown | Promise<unknown>

export interface MiddlewareOptions {
  /** 名字：插件内唯一，before / after 用它定位。 */
  name?: string
  /** 插到某个中间件之前；或段名 command / middleware / llm。 */
  before?: string
  /** 插到某个中间件之后。 */
  after?: string
}

/** 已注册指令的公开描述。 */
export interface CommandInfo {
  name: string
  aliases: string[]
  description: string
  authority: number
  module: string
}

export interface CommandActionContext {
  session: Session
  command: string
  args: string
  options: Record<string, any>
}

export interface CommandBuilder {
  authority(level: number): this
  description(text: string): this
  usage(text: string): this
  alias(...names: string[]): this
  /** 注册并返回卸载函数。返回值是 action 的返回值。 */
  action(fn: (context: CommandActionContext, ...values: any[]) => unknown): () => void
  dispose(): void
}

export interface ToolContext {
  sessionId: string
  level: string
  target?: Target
}

export interface ToolSpec {
  name: string
  description: string
  /** JSON Schema 的 properties。 */
  properties?: Record<string, any>
  required?: string[]
  parameters?: { type: 'object'; properties?: Record<string, unknown>; required?: string[] }
  execute(args: any, exec?: any): unknown
}

export interface Logger {
  info(...args: any[]): void
  warn(...args: any[]): void
  error(...args: any[]): void
  /** 只在面板打开「调试模式」时输出。 */
  debug(...args: any[]): void
}

export interface PageOptions {
  /** 侧栏路由，例如 /weather。 */
  path: string
  name: string
  icon?: string
  order?: number
  /** 页面分类元数据。控制台在独立页面栏展示已注册的路由。 */
  group?: 'home' | 'self' | 'express' | 'platform' | 'system' | 'market'
  /** 绝对地址（http://…）时直接内嵌它，否则按插件路由前缀拼。 */
  url?: string
}

export interface GenerateImageOptions {
  shape?: 'square' | 'portrait' | 'landscape' | 'wide'
  size?: string
  count?: number
  format?: 'static' | 'gif'
  references?: Uint8Array[]
}

export interface GenerateVideoOptions {
  seconds?: number
  firstFrame?: Uint8Array
}

export type GenerateImage = (prompt: string, options?: GenerateImageOptions) => Promise<Element[]>
export type GenerateVideo = (prompt: string, options?: GenerateVideoOptions) => Promise<Element>

export interface ChatModelChoice {
  provider: string
  model: string
}

export interface ChatModelConfig {
  list(): Promise<Array<ChatModelChoice & { name: string }>>
  get(target: Target, selfId: string): ChatModelChoice | null
  set(target: Target, selfId: string, choice: ChatModelChoice | null): void
}

export interface LlmFacade {
  readonly generateImage: GenerateImage
  readonly generateVideo: GenerateVideo
  readonly config: { readonly model: ChatModelConfig }
  generate(options: { text: string; system?: string; sessionId?: string; maxTokens?: number; temperature?: number; model?: ChatModelChoice }): Promise<string>
  polish(text: string, options?: { instruction?: string; maxTokens?: number; temperature?: number }): Promise<string>
  rewrite(text: string, options?: { instruction?: string; maxTokens?: number; temperature?: number }): Promise<string>
  summarize(text: string, options?: { maxLength?: number; instruction?: string; maxTokens?: number; temperature?: number }): Promise<string>
}

export interface TtsFacade {
  speak(text: string): Promise<string>
}

export interface ServerFacade {
  get(path: string, handler: (req: any, res: any) => unknown, options?: { access?: 'panel' | null }): () => void
  post(path: string, handler: (req: any, res: any) => unknown, options?: { access?: 'panel' | null }): () => void
  put(path: string, handler: (req: any, res: any) => unknown, options?: { access?: 'panel' | null }): () => void
  patch(path: string, handler: (req: any, res: any) => unknown, options?: { access?: 'panel' | null }): () => void
  delete(path: string, handler: (req: any, res: any) => unknown, options?: { access?: 'panel' | null }): () => void
}

export interface InboundMessage {
  channelName?: string
  type: Target['type']
  channelId: string
  userId: string
  userName?: string
  content?: string
  elements?: Element[]
  messageId?: string
  sn?: number
  guildId?: string
  timestamp?: number
  raw?: unknown
}

export interface AdapterRuntime {
  readonly signal?: AbortSignal
  platform: string
  log(message: string): void
  emitMessage(message: InboundMessage): void
  statusChanged?(reason?: string): void
  emitEvent?(event: string, payload: unknown): void
  speak?(text: string): Promise<string>
  supports?(capability: Capability): boolean
}

export interface AdapterSpec {
  name?: string
  platform: string
  resolvePlatform?(config: unknown): string | undefined
  capabilities?: Capability[]
  connect(config: any, runtime: AdapterRuntime): Promise<Bot>
  disconnect?(bot: Bot, config: any): Promise<void>
}

export declare class UnsupportedApiError extends Error {
  constructor(bot: Pick<Bot, 'platform' | 'id'>, api: string)
  readonly code: 'UNSUPPORTED_API'
}

export interface ChatLine {
  role: 'user' | 'assistant'
  speaker: string
  text: string
  at?: number
}

/** `room-timeline` 服务：按 Bot 分房间的对话时间线。 */
export interface RoomTimeline {
  enabled(): boolean
  read(target: Target, selfId: string, persona: string): { room: string; busy: boolean; revision: number; messages: ChatLine[] }
  record(target: Target, selfId: string, persona: string, line: ChatLine): void
}

export interface MemoryWhere {
  room: string
  persona: string
  user: string
}

/** `room-memory` 服务：房间内的长期记忆。 */
export interface RoomMemory {
  recall(where: MemoryWhere, query: string, limit: number): Array<{ id: string; text: string; changed: number }>
  remember(where: MemoryWhere, text: string): { ok: boolean; id: string }
  tools(where: MemoryWhere): ToolSpec[]
}

/** `persona` 服务：当前人格。 */
export interface PersonaService {
  current(): { id: string; name: string; body: string }
}

/** 适配器提供的表情表：服务名用 faceService(platform, botId)。 */
export interface FaceTable {
  idOf(name: string): string | number | undefined
  nameOf(id: string | number): string | undefined
}

/** 适配器提供的平台表情包源：服务名用 stickerService(platform, botId)。 */
export interface StickerSource {
  selfId: string
  active(): boolean
  read(element: Element, maxBytes: number): Promise<Buffer>
  add(path: string): Promise<string>
  rename(id: string, name: string): Promise<void>
  remove(id: string): Promise<void>
  list(limit: number): Promise<string[]>
}

export declare function faceService(platform: string, botId: string): string
export declare function stickerService(platform: string, botId: string): string
export declare function roomKey(target: Target): string

/** `ctx.chat`：聊天中枢的运行态。房间键用 roomKey(target)；没有聊天中枢时 available 为 false。 */
export interface ChatFacade {
  readonly available: boolean
  readonly lastOwnerChatAt: number
  readonly lastBotToOwner: { at: number; text: string }
  lastPrivateAt(userId: string): number
  memoryResetAt(userId: string): number
  logChat(room: string, who: string, text: string, userId?: string, options?: { via?: string; at?: number }): boolean
  deleteChatLog(day: string): void
  forgetChatLog(userId: string, query?: string, room?: string): number | undefined
  chatLogDays(): string[]
  chatLogOf(day: string, persona?: string): Array<{ t: number; chatId: string; who: string; text: string; uid?: string; forgottenAt?: number }>
  resetPersonChat(userId: string): any
  resetChat(room: string): unknown
  joinTopic(room: string): void
  leaveTopic(room: string): void
  stats(): { received?: number; sent?: number; [key: string]: unknown }
  chatCooldown(room: string): { retryAt: number; message?: string } | null
  systemSessionCooldown(key: string, options?: Record<string, unknown>): { retryAt: number; message?: string } | null
  runTurnInChat(room: string, prompt: string, options?: Record<string, unknown>): Promise<any>
  noteSaid(room: string, text: string): void
  sessions(): Record<string, { sessionId?: string; [key: string]: unknown }>
  chatOfSession(sessionId: string): string
  turnSenders(sessionId: string): string[]
  turnDirectFromOwner(sessionId: string): boolean
  speakersOf(sessionId: string): string[]
  personaOf(sessionId: string): string
  lastTextOf(sessionId: string): string
  modelFor(chat: unknown): string
  markSlowNotice(sessionId: string): void
  recentFiles(room: string): Array<{ id?: string; name: string; [key: string]: unknown }>
  recentMedia(room: string): any
  recentImages(room: string): any
  referenceImage(chat: unknown, ref: string): Promise<Buffer | null>
  stickerElement(room: string, index: number): Element | null
  filterHistory(room: string, rows: any[]): any[]
  deliver(room: string, text: string, options?: Record<string, unknown>): Promise<any>
  sendText(room: string, text: string, ...rest: any[]): Promise<any>
  sendSegments(room: string, elements: Element[], ...rest: any[]): Promise<any>
  sendImage(room: string, file: string, ...rest: any[]): Promise<any>
  sendFile(room: string, file: string, name?: string): Promise<any>
  sendSticker(room: string, name: string): Promise<boolean>
  checkSendableFile(config: Record<string, any>, file: string): { src: string; external: boolean; size: number; maxBytes: number }
  runSystemTurn(key: string, title: string, prompt: string, options?: Record<string, unknown>): Promise<string>
  remountAll(): void
  transcribe(element: Element): Promise<string>
  owner(): string
  readonly modules: { dir(): string; status(): Array<{ id: string; running?: boolean; [key: string]: unknown }> }
  connections(): Array<{ platform: string; [key: string]: unknown }>
  canReadMedia(bot: Bot, draft: unknown): boolean
  muted(room: string): boolean
  mutedUntil(room: string): number | undefined
  readonly persona: {
    current(): string
    look(sessionId?: string): { image: Buffer | null; references: unknown[]; appearance: string }
  }
}

export interface ProactiveFacade {
  readonly available: boolean
  submit(input: { text: string; itemId?: string; to?: string; link?: string; cause?: { kind: 'reply' | 'delegation' | 'background' } }): Promise<{ deliveryId: string | null; state: string }>
  statusOf(deliveryId: string): { state: string } | null
}

export interface Services {
  get<T = any>(name: string): T | null
  has(name: string): boolean
  require<T = any>(name: string): T
  names(): string[]
}

/**
 * 插件上下文。注册的东西随模块卸载自动回收：
 * 定时器、中间件、指令、工具、路由、页面、服务、机器人，一个都不用自己清。
 */
export interface Ctx {
  readonly instanceId: string
  readonly id: string
  readonly version: string
  readonly apiVersion: number
  readonly baseDir: string
  /** 本插件配置（活值；面板保存后立刻读到新值）。 */
  readonly config: Record<string, any>
  /** 全局配置：ctx.root.config 直接读，ctx.root.read() 每次拿最新。 */
  readonly root: { readonly config: Record<string, any>; read(): Record<string, any>; update(patch: any): unknown }
  updateConfig(patch: Record<string, any> | ((current: Record<string, any>) => Record<string, any>)): Record<string, any>

  readonly logger: Logger
  /** 定时器随插件卸载自动清。 */
  setInterval(ms: number, fn: () => unknown, label?: string): () => void
  setTimeout(ms: number, fn: () => unknown): () => void
  effect(fn: () => unknown): () => void

  /** 入站中间件，默认挂在 middleware 段。 */
  middleware(fn: Middleware, options?: MiddlewareOptions): () => void
  /** 注册不经过 AI 的指令。 */
  command(signature: string): CommandBuilder
  command(signature: string, handler: (session: Session, args: string) => unknown): () => void
  /** 已注册的指令；给了会话就只列它有权用的。 */
  commands(session?: Session): CommandInfo[]
  /** 注册给 AI 调用的工具：用户不能直接触发，要模型自己决定调用并传参。 */
  tool(builder: ToolSpec | ((where: ToolContext) => ToolSpec | ToolSpec[] | null)): () => void
  /** 每轮回复前追加一段上下文。 */
  prompt(fn: (where: ToolContext) => string | null | undefined): () => void
  /** 追加到系统提示的规则行；kind 是 private / group / social。 */
  rule(fn: (kind: string, config: Record<string, any>) => string | string[] | null | undefined): () => void
  defineTool(spec: ToolSpec): any

  server: ServerFacade
  page(options: PageOptions): () => void

  /** 自定义事件；别的插件 ctx.on(名字) 能收到。 */
  emit(event: string, ...args: any[]): void
  on(event: 'message', fn: (session: Session) => unknown): () => void
  on(event: 'before-parse', fn: (draft: MessageDraft) => unknown): () => void
  on(event: 'before-send' | 'send', fn: (event: SendEvent) => unknown): () => void
  on(event: NoticeName, fn: (notice: PlatformNotice) => unknown): () => void
  on(event: string, fn: (...args: any[]) => unknown): () => void

  /** 只处理这个平台的消息：ctx.platform('telegram').middleware(...)。返回同一 ctx 的收窄视图。 */
  platform(name: string): Ctx
  /** 只处理群 / 频道消息；给了 id 就再收窄到这一个。 */
  guild(id?: string): Ctx
  /** 只处理私聊。 */
  private(): Ctx

  get<T = unknown>(id: string): T | null
  /** 另一个模块导出对象的懒代理（对方晚加载也能用）。 */
  lazy<T = unknown>(id: string): T
  has(id: string): boolean
  provide(name: string, impl: any): () => void
  require<T = unknown>(name: string): T
  readonly services: Services
  readonly voice: any
  readonly sing: any
  readonly database: any
  readonly ffmpeg: any

  /** 宿主注入的消息元素工厂，无需导入。 */
  readonly h: ElementFactory
  readonly llm: LlmFacade
  /** 宿主注入；未装语音模块时为空。 */
  readonly tts?: TtsFacade
  /** 聊天中枢。 */
  readonly chat: ChatFacade
  /** 出站治理：主动消息先过档位与预算。 */
  readonly proactive: ProactiveFacade
  /** DeepSeek Harness 原生 ctx。 */
  readonly harness: Record<string, any>
  readonly bot: {
    (id?: string, platform?: string): Bot | undefined
    list(): Bot[]
  }
  readonly bots: BotsAccessor
  broadcast(targets: Target[], content: ElementSource, options?: { timeoutMs?: number }): Promise<Array<{ target: Target; ok: boolean; error?: string }>>
  adapter(spec: AdapterSpec, config?: unknown): Promise<{ bot: Bot; dispose(): Promise<void> }>

  sendTo(target: Target, content: ElementSource, options?: ModuleSendOptions): Promise<unknown>
  ask(options: any): Promise<any>
  /** 以她的人格跑一轮后台会话（不发到聊天），返回正文。 */
  think(prompt: string, options?: { title?: string; key?: string; timeoutMs?: number; noTools?: boolean; level?: string }): Promise<string>
  /** 后台会话在退避期时返回重试时间，否则 null。 */
  thinkCooldown(key?: string): { retryAt: number; message?: string } | null
  readonly chatLog: {
    read(target: Target, day: string): Array<{ t: number; target: Target; who: string; text: string; userId?: string; forgottenAt?: number }>
    append(target: Target, who: string, text: string, userId?: string): boolean
  }
  /** 工具执行时：这一轮说话的人是不是全是主人（sessionId 来自工具工厂的 where）。 */
  turnFromOwner(sessionId: string): boolean
  readonly text: {
    clean(value: unknown, label?: string): string
    isSilence(value: unknown): boolean
    sent(receipt: unknown): boolean
  }
  readonly http: {
    body(req: any): Promise<Record<string, any>>
    raw(req: any, maxBytes: number): Promise<Buffer>
    query(req: any): Record<string, string>
    send(res: any, status: number, body: unknown, type?: string): void
  }
  readonly media: { download(url: string, maxBytes: number): Promise<Buffer>; inspect(bytes: Buffer): { width: number; height: number; mime: string } }
  isOwner(session: Session): boolean
  isOwner(userId: string | number, platform: string, botId?: string): boolean
  /** 本插件的数据目录（已建好）。 */
  dataDir(...parts: string[]): string
}

/** 插件入口：使用具名导出。 */
export interface PluginModule<C = any> {
  name?: string
  version?: string
  description?: string
  /** adapter = 适配器插件。 */
  kind?: 'plugin' | 'adapter'
  /** 允许多份配置（适配器默认 true）。 */
  reusable?: boolean
  reloadOnConfig?: boolean
  config?: unknown
  Config?: unknown
  apply(ctx: Ctx, config: C): unknown
}

interface SchemaField<T> {
  default(value: T): this
  title(value: string): this
  description(value: string): this
  min(value: number): this
  max(value: number): this
  role(value: string, options?: { rows?: [number, number] }): this
  required(value?: boolean): this
  visibleWhen(key: string): this
  hidden(value?: boolean): this
  deprecated(value?: boolean): this
  experimental(value?: boolean): this
  readonly kind: string
  defaults(): Record<string, unknown>
  validate(value: unknown): { ok: boolean; value?: T; error?: string }
}

export declare const h: ElementFactory
export declare const Schema: SchemaFactory

export interface SchemaFactory {
    string(): SchemaField<string>
    boolean(): SchemaField<boolean>
    number(): SchemaField<number>
    natural(): SchemaField<number>
    percent(): SchemaField<number>
    union<T>(values: readonly T[]): SchemaField<T>
    array<T>(item: SchemaField<T>): SchemaField<T[]>
    object(shape: Record<string, SchemaField<unknown>>): SchemaField<Record<string, unknown>>
}

declare global {
  const Schema: SchemaFactory
  /** 宿主注入的消息元素工厂，无需导入。 */
  const h: ElementFactory
}
