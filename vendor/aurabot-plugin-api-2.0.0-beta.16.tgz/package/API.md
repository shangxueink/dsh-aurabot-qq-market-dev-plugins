# AuraBot 插件接口（v2）

插件是一个 ES 模块：具名导出 `name`、可选的 `config`，以及 `apply(ctx, config)`。能力全部从 `ctx` 取，注册的东西随插件卸载自动回收。开发依赖 `@aurabot/plugin-api` 提供 `Schema`、`h`、`Bot` 和类型；运行时由宿主注入同一套实现。这份文件随插件同步到数据目录 `modules/`，不要手改。

所有 Bot 地位相同。插件不要假设某个平台是「主平台」，按 `session.platform`、`session.bot` 或 `ctx.bots` 取账号。

## 最小例子

```ts
import { Schema, type Ctx } from '@aurabot/plugin-api'

export const name = '打招呼'

export const config = Schema.object({
  reply: Schema.string().default('你好呀～').description('回复内容'),
})

export function apply(ctx: Ctx, config: { reply: string }) {
  ctx.command('hello').description('打个招呼').action(({ session }) => session.send(config.reply))
}
```

| 形态 | 放哪 | 适合 |
| --- | --- | --- |
| 单文件 | `modules/<id>.mjs` | 关键词回复、链接解析 |
| 文件夹 | `modules/<id>/index.ts` 或 `package.json` 的 `main` | 分文件、带依赖、带面板 |

插件 id 取文件夹名：小写字母开头，只含小写字母、数字和 `-`，2～40 字。以 `_` 或 `.` 开头的不加载。

## 导出

| 导出 | 说明 |
| --- | --- |
| `name` / `version` / `description` | 面板显示 |
| `config`（或 `Config`） | `Schema.object({...})`；面板表单和默认值都从它派生 |
| `inject` | 依赖的服务名数组，服务就绪后才调用 `apply` |
| `kind = 'adapter'` | 适配器插件 |
| `reusable = true` | 允许多份配置（适配器默认开） |
| `reloadOnConfig = true` | 改配置后整个插件重载；默认只更新 `ctx.config` |

`Schema` 字段用 `title()` 设标签、`description()` 设提示、`role('textarea' | 'secret')` 改控件。

## 指令与工具

两者都能让插件被触发，区别在于谁来触发：

| | 指令 `ctx.command` | 工具 `ctx.tool` |
| --- | --- | --- |
| 触发者 | 用户发「前缀 + 指令名」 | 模型在回复过程中自己决定调用 |
| 经过 AI | 不经过 | 经过；结果回给模型继续说话 |
| 权限 | `.authority(1..5)` 设最低等级 | 由工具工厂按 `where.level` 决定是否提供 |
| 适合 | 确定性操作：查状态、改设置 | 需要理解语义的能力：查天气、画图 |

```ts
ctx.command('weather <city:text>')
  .description('查天气')
  .alias('天气')
  .authority(1)
  .action(async ({ session }, city) => session.send(await lookup(city)))

ctx.tool((where) => ({
  name: 'weather',
  description: '查询城市天气',
  properties: { city: { type: 'string' } },
  required: ['city'],
  execute: ({ city }) => lookup(city),
}))
```

指令前缀来自全局配置 `prefix`（默认 `[null, '/']`，不带前缀和带 `/` 都认）。`ctx.commands(session?)` 列出已注册指令；传入会话时只列它有权用的。`session.authority` 是当前等级，5 级用户可以用 `session.authorize(userId, level)` 在当前 Bot 内授权。

## 管线

```text
入站 → before-parse → message 事件 → command → middleware → llm
```

- 指令命中就结束；否则依次过中间件，最后交给模型（她自己判断回不回）。
- 中间件不调 `next()` 就算处理完；`return next()` 交给下一段。`{ name, before, after }` 控制顺序，`before`/`after` 也可以是段名。
- `session.send()` 可多次调用，每次一条独立消息。
- `session.execute(text)` 等价于当前会话又发了这句话，过完整管线，递归深度限 1。
- `ctx.platform('telegram')`、`ctx.guild(id?)`、`ctx.private()` 返回收窄视图，在视图上注册的指令、中间件和事件只对匹配的会话生效。

## ctx

| 写法 | 说明 |
| --- | --- |
| `ctx.config` / `ctx.updateConfig(patch)` | 本插件配置（活值） |
| `ctx.root.config` / `ctx.root.read()` | 全局配置（主人、指令前缀、白名单……） |
| `ctx.logger` | `info / warn / error / debug`；`debug` 只在调试模式输出 |
| `ctx.setInterval / setTimeout / effect` | 定时器与清理函数，随卸载回收 |
| `ctx.middleware(fn, options?)` | 入站中间件 |
| `ctx.command(signature)` / `ctx.commands(session?)` | 注册 / 列出指令 |
| `ctx.tool(spec \| (where) => spec[])` | 给模型调用的工具 |
| `ctx.prompt(fn)` / `ctx.rule(fn)` | 每轮追加上下文 / 系统提示规则 |
| `ctx.think(prompt, options?)` / `ctx.thinkCooldown(key?)` | 以人格跑一轮后台会话，返回正文；退避期给出 `retryAt` |
| `ctx.ask(options)` | 直接问一次模型（无人格、无会话） |
| `ctx.llm.generate / polish / rewrite / summarize` | 由 `llm` 服务提供的文本能力；失败抛错 |
| `ctx.llm.config.model` | `list()` 模型目录；`get(target, selfId)` / `set(target, selfId, choice \| null)` 读写会话的模型 |
| `ctx.sendTo(target, content, options?)` | 发到指定目标；`proactive: true` 表示主动消息，会过出站治理 |
| `ctx.broadcast(targets, content)` | 批量发送，返回每个目标的结果 |
| `ctx.proactive.submit(input)` / `statusOf(id)` | 主动消息排队，交给档位与预算决定何时发 |
| `ctx.chatLog.read(target, day)` / `append(target, who, text, userId?)` | 日流水 |
| `ctx.chat` | 聊天中枢运行态（房间键用 `roomKey(target)`）；`available` 为 false 时没有聊天中枢 |
| `ctx.server.get/post/put/patch/delete` + `ctx.http.body/raw/query/send` | 面板接口，默认走面板鉴权 |
| `ctx.page({ path, name, icon?, order?, url? })` | 侧栏页面 |
| `ctx.on / ctx.emit` | 事件 |
| `ctx.provide / ctx.require / ctx.get / ctx.lazy / ctx.has / ctx.services` | 服务 |
| `ctx.bots` / `ctx.bot(id?, platform?)` | 已上线的 Bot；多个平台用同一 ID 时要传平台 |
| `ctx.isOwner(session)` / `ctx.isOwner(userId, platform, botId?)` | 主人判定，按平台和 Bot 匹配 |
| `ctx.turnFromOwner(sessionId)` | 工具执行时，这一轮说话的人是否都是主人 |
| `ctx.llm.generateImage` / `ctx.llm.generateVideo` | 生成服务（需 `inject`） |
| `ctx.text.clean / isSilence / sent` | 模型输出进平台前的清洗 |
| `ctx.media.download / inspect` | 下载并识别媒体 |
| `ctx.dataDir(...parts)` | 本插件数据目录（已建好） |
| `ctx.harness` | DeepSeek Harness 原生 ctx |

## 目标与房间

发送目标是 `{ platform, botId, type, id }`，`type` 为 `private`、`group` 或 `channel`，`id` 原样使用平台给的频道或用户 ID（任意字符串，不限数字）。同一个人在不同 Bot 下是不同的目标。

`roomKey(target)` 生成房间键 `type:id#platform/botId`，`ctx.chat` 和记忆服务都用它。

## Bot

Bot 承载平台 API，方法面对齐 Satori：

- 消息：`sendMessage`、`sendPrivateMessage`、`getMessage`、`getMessageList`、`updateMessage`、`deleteMessage`
- 资源：`getSelf`、`getUser`、`getFriendList`、`getGuild`、`getGuildList`、`getUserList`、`getChannel`、`getChannelList`
- 表态：`createReaction`、`deleteReaction`
- 状态：`id`、`platform`、`selfId`、`status`（`registered / connecting / online / offline / error`）、`supports(capability)`

平台不支持的方法抛 `UnsupportedApiError`。平台专属能力走 `bot.internal(action, params)`，参数含义由适配器决定。只支持部分平台的插件在 `package.json` 写 `aurabot.platforms`，例如 `["telegram"]`。

```ts
for (const bot of ctx.bots.list()) {
  if (bot.status !== 'online' || !bot.supports('image')) continue
  await bot.sendMessage(channelId, [h.text('早安'), h.image(url)])
}
```

群和私聊可能共用编号的平台，用 `bot.getChannel(channelId, session.type)` 或 `bot.getMessageList(channelId, { channelType: session.type })` 指明类型。

## 消息元素

消息是 Satori 元素树。`h` 由宿主注入到全局，也可以从 `@aurabot/plugin-api` 导入。

```ts
await session.send([h.text('看这个：'), h.image('https://example.com/a.png')])
await session.send(h('at', { id: session.userId }))
h.select(h.parse('<at id="u1"/> 你好'), 'at')
```

| 元素 | 能力名 |
| --- | --- |
| `text` / `at` / `quote` | `text` / `at` / `quote` |
| `image` / `voice` / `video` / `file` | 同名 |
| `face` | `face`（平台表情，ID 由适配器的表情表解释） |
| `forward` / `poke` / `reaction` | 同名 |

发送前按 `bot.supports()` 降级：发不出去的元素变成文字。模型输出中的未知或未闭合标签整块丢弃。`<voice>要念的话</voice>` 出站时交给 TTS 服务。原消息带引用时可读 `session.quote`，至少含消息 ID 与频道 ID。

## 服务

`ctx.provide(name, impl)` 提供服务；同名服务只能有一个持有者，面板会显示冲突双方。消费方三种取法：

- `export const inject = ['llm']`：服务就绪才启动，提供者下线时本插件随之释放，恢复后重启。
- `ctx.require(name)`：必须可用，没有就抛错。
- `ctx.services.get(name)` / `ctx.lazy(id)`：可选能力，没有时自己降级。

宿主与内置模块提供的服务：

| 服务名 | 类型 | 提供者 |
| --- | --- | --- |
| `llm` | `LlmFacade` | llm |
| `tts` / `voice` / `asr` | 语音合成 / 语音条 / 识别 | voice、asr |
| `generateImage` / `generateVideo` | 生成函数 | imagegen、video |
| `room-timeline` | `RoomTimeline` | 宿主 |
| `room-memory` | `RoomMemory` | memory |
| `persona` | `PersonaService` | persona |
| `mutes` | 会话静音表 | commands |
| `faceService(platform, botId)` | `FaceTable` | 各平台适配器 |
| `stickerService(platform, botId)` | `StickerSource` | 支持平台表情包的适配器 |

按 Bot 区分的服务用 `faceService(...)`、`stickerService(...)` 生成服务名，适配器以自己的平台和 `ctx.instanceId` 提供，消费方按 `session.platform` 与 `session.bot.id` 取。

## 事件

| `ctx.on` 事件 | 参数与时机 |
| --- | --- |
| `before-parse` | 解析入站消息前按注册顺序调用，可异步替换 `draft.elements` |
| `message` | 指令和中间件之前收到 `Session` |
| `before-send` | 参数含 `bot`、`target`、`elements`；返回 `true` 取消此次发送 |
| `send` | 发送成功后；平台返回消息 ID 时写入 `messageId`，拆成多条时每个 ID 触发一次 |
| `guild-member-added / removed / updated` | 成员变更，带 `botId`、`guildId`、`userId` 与平台资源 `data` |
| `friend-request / guild-request / guild-member-request` | 好友、邀请或入群申请，附言在 `data.message` |
| `message-deleted / message-updated` | 撤回或编辑，按 `platform`、`botId`、`channelId`、`messageId` 定位 |
| `reaction-added / reaction-removed` | 表态变化 |

入队和被取消的发送不会触发 `send`。

## 适配器

适配器插件导出 `kind = 'adapter'`，在 `apply` 里调用 `ctx.adapter(spec, config)`。

```ts
export const name = 'Example'
export const kind = 'adapter'
export const config = Schema.object({ token: Schema.string().role('secret').required() })

export async function apply(ctx, config) {
  await ctx.adapter({
    platform: 'example',
    capabilities: ['text', 'image', 'at', 'quote'],
    async connect(cfg, runtime) {
      const bot = new ExampleBot(cfg, runtime)
      await bot.login()
      return bot
    },
    async disconnect(bot) {
      await bot.logout()
    },
  }, config)
}
```

生命周期：

1. 宿主调用 `connect(config, runtime)`；适配器建立连接，返回一个继承 `Bot` 的实例，此时 `status` 为 `online`。
2. 收到消息时调用 `runtime.emitMessage({ type, channelId, userId, content 或 elements, messageId, guildId? })`；平台事件用 `runtime.emitEvent(name, payload)`。
3. 掉线或恢复时先改 `bot.status`，再调 `runtime.statusChanged(reason?)`。重连期间保持同一个 `bot.id`。
4. 插件卸载、配置变化或 `runtime.signal` 中止时，宿主调用 `disconnect(bot, config)`，适配器释放连接和定时器。

一个适配器插件可以有多份配置，每份是一个独立 Bot。平台专属服务（表情表、表情包源）在 `apply` 里用 `ctx.provide(faceService(platform, ctx.instanceId), table)` 提供。

## 生成图片与视频

声明 `inject = ['generateImage']` 后，`await ctx.llm.generateImage(prompt, { references, shape, size, count, format })` 返回图片元素数组。`references` 是按顺序排列的图片字节。

`await ctx.llm.generateVideo(prompt, { seconds, firstFrame })` 返回一个 MP4 视频元素。服务只负责生成，是否发送由插件决定。提供者在生成过程中下线时调用会抛错。

## 开发

- 入口写 `.ts`，同目录的 `aurabot.d.ts` 提供 `ctx`、`session`、`h` 的补全。
- 保存即热重载（监听整个插件文件夹）。
- 日志在 `<数据目录>/data/logs/`。
